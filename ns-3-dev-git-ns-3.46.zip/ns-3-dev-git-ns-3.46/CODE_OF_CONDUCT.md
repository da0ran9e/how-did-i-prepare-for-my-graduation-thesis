# ns-3 Code of Conduct

The ns-3 code of conduct is available in the following website:

<https://www.nsnam.org/about/governance/policies/>
