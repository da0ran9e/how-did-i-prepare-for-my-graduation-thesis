#ifndef NS3_CORE_CONFIG_H
#define NS3_CORE_CONFIG_H

#cmakedefine HAVE_UINT128_T
#cmakedefine01 HAVE___UINT128_T
#cmakedefine INT64X64_USE_128
#cmakedefine INT64X64_USE_DOUBLE
#cmakedefine INT64X64_USE_CAIRO
#cmakedefine01 HAVE_SYS_TYPES_H
#cmakedefine01 HAVE_SYS_STAT_H
#cmakedefine01 HAVE_DIRENT_H
#cmakedefine01 HAVE_GETENV
#cmakedefine01 HAVE_SIGNAL_H

#endif // NS3_CORE_CONFIG_H
